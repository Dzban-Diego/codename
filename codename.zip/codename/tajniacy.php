<?php

    // Word base
    $data = "";
    $words = array("milioner","mysz","soczewka","masa","pazur","gotyk","praca","grzyb","wiatr","płot","dzięcioł","bawełna","bicz","nowy jork","koło","robak","karta","pasta","podkowa","lina","klatka","tusza","tablica","lód","szkoła","jednorożec","bomba","punkt","hak","francuz","sieć","kontakt","oliwa","funt","noc","antarktyka","kościół","samochód","ośmiornica","księżyc","ryba","grzmot","pochodnia","śnieg","mistrz","spadek","hollywood","figura","zmywacz","tuba","materiał","szczęście","ślimak","chochlik","tokio","kot","pas","trójkąt","pociecha","poczta","łuk","czekolada","kasyno","kangur","krasnal","saturn","opera","amazonka","ruletka","rząd","hotel","kropka","humor","diament","doktor","klamka","but","róg","podkład","widelec","tchórz","kod","gniazdko","nauczyciel","bar","kozioł","pirat","szpilka","berlin","żabka","orzech","feniks","siano","krzyż","noga","wybuch","wieloryb","nora","niebo","gołąb","dzwon","obcy","dziobak","gładki","plik","duch","miód","ojazd","olimp","wstęp","płyta","czapa","usta","mikroskop","gra","kostium","korona","jagoda","szczyt","lew","golf","życie","głowa","plastik","wieża","ogień","waga","pociąg","wkład","centaur","basen","keczup","pająk","ząb","obsada","pterodaktyl","pudło","moskwa","fartuch","lakier","beczka","silnik","trawa","maks","śmieć","stadion","truteń","grabarz","niedźwiedź","ekran","nektar","łożysko","promień","łódź","klucz","złodziej","talia","kamień","blat","afryka","bąk","nóż","babka","góra","siła","australia","ninja","film","muszla","perła","lis","bawełna","ucho","serce","anglia","świnia","ręka","grecja","kręgi","jowisz","igła","słup","rekin","lody","karawan","zieleń","rzym"," kraków","ruda","żuraw","zwoje","powietrze","bank","zamek","kontakt","żubr","księżniczka","bermudy","napad","gaz","kiwi","dziura","loch ness","europa","szekspir","wieżowiec","krówka","rzęsa","lot","strona","helikopter","prawo","belka","kolec","gracja","kasa","nos","robot","złoto","model","holender","zmiana","krzesło","rewolucja","plastik","cień","stopa","statek","wąż","mucha","butelka","komórka","ława","merkury","spadochron","czujka","koncert","pies","budowa","dwór","konar","szpieg","anioł","skorupa","kwadrat","guma","mur","as","port","połączenie","niemcy","róża","mamut","blok","wachlarz","pielęgniarka","kret","ogier","pustka","czas","gigant","strzał","piramida","rama","ambulans","pierścień","tusz","zebra","rzut","ziemia","rękawica","szkło","sztuka","rak","satelita","talerz","foka","placek","francja","stan","himalaje","pistolet","język","czar","nić","wiedżma","limuzyna","pan","torebka","skorpion","aztek","koń","klawisz","kucharz","laska","królowa","opoka","zespół","kaczor","woda","ambasada","prawnik","północ","oko","rycerz","sznur","kość","orzeł","centrum","pingwin","król","organy","superbohater","żuk","geniusz","paleta","meksyk","jabłko","olej","laser","trąba","gwiazda","siekacz","ogon","kaptur","pole","guzik","wydech","drzewo","pilot","groszek","sukienka","świerszcz","dusza","pokrywka","szpital","teleskop","gnat","teatr","sokół","maj","marchew","chiny","szkocja","fala","wiosna","szmugiel","znak","ciało","egipt","kciuk","toaleta","smok","szafa","trucizna","dzień","przewodnik","naukowiec","londyn","atlantyda","cebula","wojna","bal","dno","waszyngton","pekin","strumień","dania","rura","twarz","królik","taniec","korzenie","pupil","choroba","paluszki","rakieta","donice","policja","dywan","jatka","stołek","nurek","jaja","papier","samolot","dinozaur","ameryka","splot","miedź","lina","stopień","awaria","żelazo","polska","żołnierz","kalosz","żebro","stół");
    $jwos = array("Rozmyślać","Zebranie","Służba","Kielich","Sól","Chleb","Studnia","Pierworodny","Winorośl","Pieśń","Szabat","Namiot","Świecznik","Ofiara","Przebaczyć","Oliwa","Święto","Róg","Pycha","Jeroboam","Odstępca","Przypowieść","Syn","Jordan","Dziedzictwo","Lekcja","Kierownictwo","Filistyni","Bożek","Rodowód","Modlitwa","Przyjaźń","Pasterz","Troska","Wszechmocny","Koza","Dekret","Brama","Radość","Doradca","Bogactwo","Skała","Skrucha","Liban","Rydwan","Chrzest","Siewca","Perła","Królestwo","Zakwas","Zbór","Starszy","Księga","siła","szata","kadzidło","włócznia","Gwiazdy","Jonasz","Pustkowie","Znaki","Ucisk","Owoc","Chwała","Baal","Zagłada","Woń","Namaścić","Sandały","Zbroja","Cherub","Eden","Abel","Proroctwo","Patriarcha","Izrael","Świątynia","Król","Mesjasz","Sędzia","Pascha","Apostołowie","Laska","Cud","Zmartwychwstanie","Niniwa","Babilon","Oślica","Arka","Jan","Bestia","wiara","miłość","pokora","Samuel","Grzech","Jerozolima","Asyria","Goliat","Estera","Mury","Eufrat","wędrówka","Ogień","Egipt","Józef","Dyby","Gehenna","Szeol","Lewiatan","Trąd","Nieczystość","Doradca","Przyjaciel","Kapłan","Przymierze","Tykwa","Tron","Seraf","Armagedon","Pokolenie","Tyr","Żegluga","Korynt","List","Nawrócić","Ukamienować","Pal","zdrada","Srebrniki","kazanie","przykład","wino","cierpliwość","Sztorm","wojna","Kanaan","Nagroda","Kara","Nefilim","Kusić","Prawda","Monogamia","Kult","Bałwochwalstwo","Cudzołóstwo","Niebiosa","Ślepota","Gościnność","Przybytek","Obłuda","Faryzeusz","Saduceusz","Rzym","Sanhedryn","Plagi","Szarańcza","Juda","Biblia","Miska soczewicy","Syjon","Jehowa","Jezus","Chrystus","Bóg","Aniołowie","Jezebel","Duch Święty","Efod","Chleby pokładne","Cham","Mirra","Aloes","Wielbłąd","Chleb przaśny","Jafet","Sem","Tęcza","Zwoje","Raj","Adam","Ewa","Smierć");
    $jwtp = array("adam","anioł","apostoł","arka","armagedon","biblia","bóg","chrzest","cierpliwość","dobroć","drzewo","duch","ewa","hiob","miecz","noe","świątynia","jezus","krzew","ryby","owce","kozy","nisan","wieża","pal","szatan","grzech","owoc","śmierć","kara","karcenie","niewiasta","prawo","miłość","radość","pokój","życzliwość","wiara","łagodność","opanowanie","raj","tysiąc","666","świadek","zło","rzym","okup","dawid","salomon","jan","dusza","zbroja","zdrada","święty","siedem", "morderstwo", "judasz","sen","prorok","proroctwo","maria","abraham","wieczny","rodzina","wszechświat","pisarz","wdzięczność","ojciec","więź","zebranie","modlitwa","morderstwo","miecz","eden","ludzkość","grzech","bunt","pragnienie","doskonałość","potomstwo","kain","marność","dar","ofiara","kapłan","doskonałość","pasterz","stworzenie","przymierze","cherub","stanowisko","pobudka","słowo","przestroga","przyjaciel","przemoc","sukces","statek","budowa","jedzenie","polecenie","deszcz","zwierzęta","dowód","śmiech","jerozolima","betlejem","egipt","morze","pustkowie","plac","potop","sara","władca","wschód","podróż","wyprowadzka","sygnał","trąba","wielbłąd","osioł","obóz","rzeka","miasto","majątek","kraj","kanaan","sąsiad","fundament","zbór","symbol","obietnica","żałoba","wdowa","mąż","strata","krewny","teściowa","plon","bałwochwalstwo","prawo","ślub","tragiedia","zwyczaj","dziecko","kupiec","chleb","głód","wygrana","gorycz","lud","tydzień","wpływ","piękno","pokłosie","pole","żniwa","posiłek","obcy","pisklę","świt","księga","zwój","papirus","sędzia","przymiot","zboże","wysiłek","balsam","bogactwo","bieda","serce","umysł","siła","ciemność","duma","bliźni","rada","dziadek","odpoczynek","obłok","starszy","wzgórze","wiatr","robotnik","niewolnik","studnia","srebro","złoto","szata","izrael","święto","rywal","hańba","rzecznik","faraon","łzy");
    $jwmix = array("anioł","dobroć","drzewo","hiob","noe","krzew","ryby","owce","kozy","nisan","wieża","szatan","śmierć","karcenie","niewiasta","pokój","życzliwość","łagodność","opanowanie","tysiąc","666","świadek","okup","dawid","salomon","dusza","siedem","judasz","sen","prorok","maria","abraham","wieczny","rodzina","wszechświat","pisarz","wdzięczność","ojciec","więź","morderstwo","miecz","ludzkość","bunt","pragnienie","potomstwo","kain","marność","dar","doskonałość","stworzenie","stanowisko","pobudka","słowo","przestroga","przemoc","sukces","statek","budowa","jedzenie","polecenie","deszcz","zwierzęta","śmiech","betlejem","morze","plac","potop","sara","władca","wschód","podróż","wyprowadzka","sygnał","trąba","osioł","obóz","rzeka","miasto","majątek","kraj","sąsiad","fundament","symbol","obietnica","żałoba","wdowa","mąż","strata","krewny","teściowa","plon","prawo","ślub","tragiedia","zwyczaj","dziecko","kupiec","głód","wygrana","gorycz","lud","tydzień","wpływ","piękno","pokłosie","pole","żniwa","posiłek","obcy","pisklę","świt","zwój","papirus","przymiot","zboże","wysiłek","balsam","bieda","serce","umysł","ciemność","duma","bliźni","dziadek","odpoczynek","obłok","wzgórze","wiatr","robotnik","niewolnik","srebro","złoto","rywal","hańba","rzecznik","faraon","łzy","Rozmyślać","Zebranie","Służba","Kielich","Sól","Chleb","Studnia","Pierworodny","Winorośl","Pieśń","Szabat","Namiot","Świecznik","Ofiara","Przebaczyć","Oliwa","Święto","Róg","Pycha","Jeroboam","Odstępca","Przypowieść","Syn","Jordan","Dziedzictwo","Lekcja","Kierownictwo","Filistyni","Bożek","Rodowód","Modlitwa","Przyjaźń","Pasterz","Troska","Wszechmocny","Koza","Dekret","Brama","Radość","Doradca","Bogactwo","Skała","Skrucha","Liban","Rydwan","Chrzest","Siewca","Perła","Królestwo","Zakwas","Zbór","Starszy","Księga","siła","szata","kadzidło","włócznia","Gwiazdy","Jonasz","Pustkowie","Znaki","Ucisk","Owoc","Chwała","Baal","Zagłada","Woń","Namaścić","Sandały","Zbroja","Cherub","Eden","Abel","Proroctwo","Patriarcha","Izrael","Świątynia","Król","Mesjasz","Sędzia","Pascha","Apostołowie","Laska","Cud","Zmartwychwstanie","Niniwa","Babilon","Oślica","Arka","Jan","Bestia","wiara","miłość","pokora","Samuel","Grzech","Jerozolima","Asyria","Goliat","Estera","Mury","Eufrat","wędrówka","Ogień","Egipt","Józef","Dyby","Gehenna","Szeol","Lewiatan","Trąd","Nieczystość","Doradca","Przyjaciel","Kapłan","Przymierze","Tykwa","Tron","Seraf","Armagedon","Pokolenie","Tyr","Żegluga","Korynt","List","Nawrócić","Ukamienować","Pal","zdrada","Srebrniki","kazanie","przykład","wino","cierpliwość","Sztorm","wojna","Kanaan","Nagroda","Kara","Nefilim","Kusić","Prawda","Monogamia","Kult","Bałwochwalstwo","Cudzołóstwo","Niebiosa","Ślepota","Gościnność","Przybytek","Obłuda","Faryzeusz","Saduceusz","Rzym","Sanhedryn","Plagi","Szarańcza","Juda","Biblia","Miska soczewicy","Syjon","Jehowa","Jezus","Chrystus","Bóg","Aniołowie","Jezebel","Duch Święty","Efod","Chleby pokładne","Cham","Mirra","Aloes","Wielbłąd","Chleb przaśny","Jafet","Sem","Tęcza","Zwoje","Raj","Adam","Ewa","Smierć");

    // Get from url
    $wb = htmlspecialchars($_GET["wb"]);
    $roomname = htmlspecialchars($_GET["r"]);
    $chwork = "OK";

    if($roomname != ""){
        // Set base
        if($wb == "k"){
            $base = $words;
        }else if($wb == "jt"){
            $base = $jwtp;
        }else if($wb == "jo"){
            $base = $jwos;
        }else if($wb == "jm"){
            $base = $jwmix;
        }else if($wb == "m"){
            $base = array_merge($jwmix, $words);
        }

        // Mix base
        shuffle($base);

        // Save word
        for($i=0; $i<=24 ;$i++){
            $my_file = 'rooms/'.$roomname.'/words.txt';
            $file = fopen($my_file, 'w') or die('Cannot open file:  '.$my_file);
            $data = $data.$base[$i].",";
            fwrite($file, $data);
            fclose($file);
        }

        // Set teams
        $col = array("mred","mblu","mwhi","mbla");
        $ran = rand(1,2);
        if($ran == 1){
            $col[0] = "mblu";
            $col[1] = "mred";
        }

        // Set key
        $prekey = array(0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,2,2,2,2,2,2,2,3);
        $key = array(0,0,0,0,0,0,0,0,0,1,1,1,1,1,1,1,1,2,2,2,2,2,2,2,3);
        shuffle($prekey);

        for($i=0; $i<=24 ;$i++){
            $key[$i] = $col[$prekey[$i]];
        }

        // Save key
        $datakey = "";
        for($i=0; $i<=25 ;$i++){
            $key[25] = $col[0];
            $key_file = 'rooms/'.$roomname.'/key.txt';
            $keyfile = fopen($key_file, 'w') or die('Cannot open file:  '.$key_file);
            $datakey = $datakey.$key[$i].",";
            fwrite($keyfile, $datakey);
            fclose($keyfile);
        }

        // Go to html
        header('Location: http://klimczewski.pl/tajniacy/board/?r='.$roomname);
        header('Cache-Control: no-cache, no-store, must-revalidate');
        header('Pragma: no-cache');
        header('Expires: 0');
        
    }else{
        header('Location: http://klimczewski.pl/tajniacy/');
        $chwork = "NO ROOM";
    }

    // LOG
    $myDate = date('m/d/Y G.i:s');
    $oldfile = file_get_contents("log.txt");
    $log = fopen("log.txt", 'w') or die('Cannot open file:  '."log.txt");
    $line = $oldfile.$myDate."--".$roomname."--".$chwork."\n";
    fwrite($log, $line);
    fclose($log);
    
    exit;
?>